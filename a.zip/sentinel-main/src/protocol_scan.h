// protocol_scan.h — Protocol Scan Header
// Version: 1.1.0

#ifndef PROTOCOL_SCAN_H
#define PROTOCOL_SCAN_H

void start_protocol_scan(const char *def_file, int dwell_us);

#endif
