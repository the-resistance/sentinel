// signal_map.h
// version: v1.3.1

#ifndef SIGNAL_MAP_H
#define SIGNAL_MAP_H

const char* resolve_signal(uint64_t freq);

#endif